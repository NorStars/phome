<?php

define('EmpireDown_VERSION','2.5');

define('EmpireDown_LASTTIME','201006022030');

define('EmpireDown_UPDATE','1');

?>