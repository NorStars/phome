<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>��Ա���� - Powered by EmpireDown</title>
<meta name="keywords" content="��Ա����" />
<meta name="description" content="��Ա����" />
<link href="/edown25/skin/default/css/style.css" rel="stylesheet" type="text/css" />
</head>
<body topmargin="0">
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" background="/edown25/skin/default/images/menu_bg.gif" class="tablebordercss">
  <tr> 
    <td height="25"><table width="100%" border="0" cellspacing="1" cellpadding="3" class="topfontcss">
        <tr>
          <td width="50%"><script src="/edown25/iframe/loginjs.php"></script></td>
          <td><div align="right">
		  		<a href="/edown25/">������ҳ</a> | <a href="/edown25/list/class.html">��������</a> | <a href="/edown25/list/list1_1.html">�������</a> | <a href="/edown25/list/list2_1.html">�����Ƽ�</a> | <a href="/edown25/list/list3_1.html">��������</a></div></td>
        </tr>
      </table></td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" height="6">
  <tr>
    <td></td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr> 
      <td width="27%" height="65">
	  <a href="http://www.phome.net"><img height="65" alt="�۹�����" src="/edown25/skin/default/images/logo.jpg" width="180" border="0" /></a>
	  </td>
      <td width="63%" align="center">
	  <a href="http://www.phome.net" target="_blank"><img src="/edown25/skin/default/images/opensource.gif" alt="�۹�CMSϵ��������Դ����" width="468" height="60" border="0" /></a>
	  </td>
      <td width="10%"> 
          <table cellspacing="0" cellpadding="0" width="100%" border="0">
		    <tr> 
              <td>
			  <img height="16" hspace="2" src="/edown25/skin/default/images/home.gif" width="16" align="absmiddle" vspace="2" /><a onclick="this.style.behavior='url(#default#homepage)';this.setHomePage('http://www.phome.net');" href="#edown">��Ϊ��ҳ</a>
			  </td>
            </tr>
		    <tr> 
              <td>
			  <img height="16" hspace="2" 
                  src="/edown25/skin/default/images/bookmark.gif" width="16" align="absmiddle" 
                  vspace="2" /><a onclick="window.external.addFavorite(location.href,document.title)" href="#edown">�����ղ�</a>
              </td>
            </tr>
            <tr> 
              <td>
			  <img height="17" hspace="2" src="/edown25/skin/default/images/email.gif" width="16" align="absmiddle" vspace="2" /><a href="#edown">��ϵ����</a>
			  </td>
            </tr>
          </table>
      </td>
    </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" height="6">
  <tr> 
    <td></td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" background="/edown25/skin/default/images/menu_bg.gif" class="tablebordercss">
  <tr> 
    <td height="25"><table width="100%" border="0" cellspacing="1" cellpadding="3">
        <tr> 
          <td height="25" align="center" class="classmenucss"> 
            <a href="/edown25/list/1_1.html">���繤��</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="/edown25/list/6_1.html">Ӧ�ù���</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="/edown25/list/11_1.html">ͼ��ͼ��</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="/edown25/list/16_1.html">��ý����</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="/edown25/list/21_1.html">����Դ��</a>
          </td>
        </tr>
      </table></td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" height="6">
  <tr> 
    <td></td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" class="gginfocss">
  <tr>
    <td>
		<table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
        <tr> 
          <td width="23" height="24">
		  <div align="center"><img src="/edown25/skin/default/images/gonggao.gif" width="20" height="16" align="middle" /></div>
		  </td>
          <td width="326" valign="middle">
			<script src="/edown25/data/js/gg.js"></script>
          </td>
          <td width="427" align="right"> 
              <table border="0" cellpadding="3" cellspacing="1">
			  <form name="searchform" method="post" action="/edown25/search/index.php">
			  <tr>
			  	  <td valign="middle">����: 
                    <select name="show">
					<option value="0">����</option>
					<option value="1" selected>������</option>
					<option value="2">�������</option>
					</select> <input name="keyboard" type="text"><input type="submit" name="Submit" value="����"> [<a href="/edown25/list/search.html">�߼�����</a>]
				</td>
              </tr>
              </form>
              </table>
          </td>
        </tr>
      	</table>
	</td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" height="6">
  <tr> 
    <td></td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" class="tablebordercss">
  <tr>
    <td>
      <div align="center">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="center">
			<a href="http://www.phome.net/OpenSource/" target="_blank"><img src="/edown25/skin/default/images/EmpireCMS51os.jpg" border="0" width="776" height="134" alt="�۹�CMSȫ�濪Դ" /></a></td>
          </tr>
        </table>
      </div>
	</td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" height="6">
  <tr> 
    <td></td>
  </tr>
</table> 
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" class="tablebordercss">
  <tr>
    <td height="23" background="/edown25/skin/default/images/header_bg.gif"> 
      <table width="100%" border="0" cellspacing="1" cellpadding="3">
        <tr>
          <td>����λ��: <?=$url?></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" height="6">
  <tr> 
    <td></td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="170" valign="top"> 
      <table width="98%" border="0" cellpadding="0" cellspacing="0" class="tablebordercss">
        <tr> 
          <td height="27" background="/edown25/skin/default/images/bclass_bg.gif"> 
            <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="41">&nbsp;</td>
                <td width="85" valign="bottom" background="/edown25/skin/default/images/titlebg_l.gif"> 
                  <div align="center"><strong><a href="/edown25/cp/">��Ա����</a></strong></div></td>
                <td width="41"><img src="/edown25/skin/default/images/titlebg_r.gif" width="7" height="27" /></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td>
            <table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr> 
                <td valign="top"><table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#E7F1FE">
                    <tr> 
                      <td height="25" bgcolor="#FFFFFF"> <div align="center"><a href="/edown25/register/">ע���Ա</a></div></td>
                    </tr>
                    <tr> 
                      <td height="25" bgcolor="#FFFFFF"> <div align="center"><a href="/edown25/EditInfo/">�޸�����</a></div></td>
                    </tr>
                    <tr> 
                      <td height="25" bgcolor="#FFFFFF"> <div align="center"><a href="/edown25/fava/">�ղؼ�</a></div></td>
                    </tr>
                    <tr> 
                      <td height="25" bgcolor="#FFFFFF"> <div align="center"><a href="/edown25/my/">�ҵ�״̬</a></div></td>
                    </tr>
                    <tr> 
                      <td height="25" bgcolor="#FFFFFF"> <div align="center"><a href="/edown25/card/">�㿨��ֵ</a></div></td>
                    </tr>
                    <tr> 
                      <td height="25" bgcolor="#FFFFFF"> <div align="center"><a href="/edown25/buybak/">��ֵ��¼</a></div></td>
                    </tr>
                    <tr> 
                      <td height="25" bgcolor="#FFFFFF"> <div align="center"><a href="/edown25/downbak/">���Ѽ�¼</a></div></td>
                    </tr>
                    <tr> 
                      <td height="25" bgcolor="#FFFFFF"> <div align="center"><a href="/edown25/AddSoft/">��������</a></div></td>
                    </tr>
                    <tr> 
                      <td height="25" bgcolor="#FFFFFF"> <div align="center"><a href="/edown25/login/">���µ�½</a></div></td>
                    </tr>
                    <tr> 
                      <td height="25" bgcolor="#FFFFFF"> <div align="center"><a href="/edown25/phome?phome=exit" onclick="return confirm('ȷ��Ҫ�˳�?');">�ʺ��˳�</a></div></td>
                    </tr>
                  </table></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td width="608" valign="top">