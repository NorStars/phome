</td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" height="12">
  <tr> 
    <td></td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="3" cellspacing="1" class="tablebordercss">
  <tr> 
    <td bgcolor="#E7F1FE"> 
      <table width="100%" border="0" cellspacing="1" cellpadding="3">
        <tr> 
          <td height="36" align="center">
		  	<a href="/edown25/">��վ��ҳ</a> | <a href="#">��������</a> | <a href="#">��������</a> | <a href="#">������</a> | <a href="#">��ϵ����</a> | <a href="#">��������</a> | <a href="http://www.phome.net" target="_blank">����֧��</a> 
          </td>
        </tr>
        <tr> 
          <td><div align="center">Powered by <strong><a href="http://www.phome.net" target="_blank">EmpireDown</a></strong> 
              <strong><font color="#FF9900">2.5</font></strong>&nbsp; &copy; 2002-2009 
              <a href="http://www.digod.com" target="_blank">EmpireSoft Inc.</a></div></td>
        </tr>
      </table>
	</td>
  </tr>
</table>
</body>
</html> 