<?php
$class_r=array();
@include("class1.php");
@include("ztclass.php");

?>