<?php
//level
$level_r=array();
$level_r[1]=Array('groupid'=>1,
'groupname'=>'��ͨ��Ա',
'level'=>1,
'checked'=>0,
'favanum'=>60,
'daydown'=>0);
$level_r[2]=Array('groupid'=>2,
'groupname'=>'VIP��Ա',
'level'=>2,
'checked'=>0,
'favanum'=>100,
'daydown'=>0);

//level
?>